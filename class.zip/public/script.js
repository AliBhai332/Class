const socket = io();
let localStream;
let peers = {};

// Login
function login() {
  const password = document.getElementById("password").value;
  const errorMessage = document.getElementById("error-message");

  if (password === "teacher123" || password === "student123") {
    document.getElementById("login-container").classList.add("hidden");
    document.getElementById("classroom").classList.remove("hidden");
    startVideo();
    socket.emit("join-class", { role: password === "teacher123" ? "teacher" : "student" });
  } else {
    errorMessage.textContent = "Incorrect password. Please try again.";
  }
}

// Video and Audio
async function startVideo() {
  try {
    localStream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
    document.getElementById("localVideo").srcObject = localStream;

    socket.on("signal", async ({ from, signal }) => {
      if (!peers[from]) {
        peers[from] = new RTCPeerConnection();

        // Add local tracks
        localStream.getTracks().forEach((track) => peers[from].addTrack(track, localStream));

        // Add remote stream
        peers[from].ontrack = (event) => {
          const remoteVideo = document.createElement("video");
          remoteVideo.srcObject = event.streams[0];
          remoteVideo.autoplay = true;
          document.getElementById("remoteVideos").appendChild(remoteVideo);
        };

        if (signal) {
          await peers[from].setRemoteDescription(new RTCSessionDescription(signal));
          if (signal.type === "offer") {
            const answer = await peers[from].createAnswer();
            await peers[from].setLocalDescription(answer);
            socket.emit("signal", { to: from, signal: peers[from].localDescription });
          }
        }
      }
    });
  } catch (error) {
    console.error("Error accessing media devices:", error);
    alert("Camera or microphone access is blocked. Please allow permissions in your browser settings.");
  }
}

// Chat
function sendMessage() {
  const message = document.getElementById("chat-input").value;
  if (message.trim()) {
    socket.emit("chat-message", message);
    document.getElementById("chat-box").innerHTML += `<p><strong>You:</strong> ${message}</p>`;
    document.getElementById("chat-input").value = "";
  }
}

socket.on("chat-message", (message) => {
  document.getElementById("chat-box").innerHTML += `<p>${message}</p>`;
});

// Leave Class
function leaveClass() {
  location.reload();
}