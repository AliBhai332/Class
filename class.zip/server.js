const express = require("express");
const http = require("http");
const { Server } = require("socket.io");

const app = express();
const server = http.createServer(app);
const io = new Server(server);

app.use(express.static("public"));

io.on("connection", (socket) => {
  console.log("User connected:", socket.id);

  socket.on("join-class", (data) => {
    console.log(`${data.role} joined: ${socket.id}`);
    socket.broadcast.emit("user-joined", { id: socket.id, role: data.role });
  });

  socket.on("signal", (data) => {
    socket.to(data.to).emit("signal", { from: socket.id, signal: data.signal });
  });

  socket.on("chat-message", (message) => {
    io.emit("chat-message", message);
  });

  socket.on("disconnect", () => {
    console.log("User disconnected:", socket.id);
  });
});

server.listen(3000, () => console.log("Server running on http://localhost:3000"));